import styled, { css } from 'styled-components';

export const MainContainer = styled.div`
    min-height: 83vh;
    margin: 0;
    padding: 0;
    height: auto;
    background-color: #da0101;
    BORDER: 1PX SOLID #b1b1b1;
`;


