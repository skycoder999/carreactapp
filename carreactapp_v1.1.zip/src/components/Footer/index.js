import React from 'react'
import * as Styled from './styled';
export default function Footer() {
    return (
        <Styled.Footer>
            <ul>
                <li><p>Copyright @2020</p></li>
            </ul>
        </Styled.Footer>
    )
}
