import React from 'react'

export default function Accesories() {
    return (
        <div>
            Accesories
        </div>
    )
}
